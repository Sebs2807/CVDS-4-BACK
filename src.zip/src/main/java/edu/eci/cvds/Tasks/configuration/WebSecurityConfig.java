package edu.eci.cvds.Tasks.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import edu.eci.cvds.Tasks.service.MongoUserDetailsService;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf().disable()
                .cors(cors -> cors.disable())
                .authorizeRequests()
                .requestMatchers("/auth/addRole").permitAll()
                .anyRequest().permitAll();
        return http.build();
                // .authorizeHttpRequests((requests) -> requests
                //         .requestMatchers("/login/**","/signup/**","/auth/**").permitAll() // Login accesible para todos
                //         .requestMatchers("/tasks/**").hasRole("ADMIN") // Solo para usuarios con rol USER
                //         .requestMatchers("/analytics/**").hasRole("ADMIN") // Solo para administradores con rol
                //         .anyRequest().permitAll())
                // .formLogin((form) -> form
                //                 .loginPage("/login")
                //                 .permitAll())
                // .logout((logout) -> logout.permitAll());

    }

    @Bean
    public UserDetailsService userDetailsService() {
        return new MongoUserDetailsService(); // Implementación personalizada para MongoDB
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(); // Utiliza BCrypt para cifrar las contraseñas
    }
}
package edu.eci.cvds.Tasks.model;


public enum Difficulty{
    ALTO,MEDIO,BAJO
}
